import 'package:flutter/material.dart';
import 'package:uber_cm/services/appwrite_service.dart'; [cite: 1, 2, 3]

class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  // Rôle par défaut (on peut le changer via ton UI de sélection)
  String _selectedRole = 'client';
  bool _isLoading = false;

  final AppwriteService _appwrite = AppwriteService();

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      // Appel de la Cloud Function que nous avons configurée ensemble
      await _appwrite.registerUser(
        _emailController.text.trim(),
        _passwordController.text.trim(),
        _nameController.text.trim(),
        _selectedRole,
        _phoneController.text.trim(),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Inscription réussie ! Connectez-vous.")),
      );

      // Ici, tu peux rediriger vers l'écran de Login ou Home
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Erreur : ${e.toString()}")));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    // Garde tes champs de texte actuels ici [cite: 2]
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(labelText: "Nom complet"),
                      validator: (v) => v!.isEmpty ? "Champ requis" : null,
                    ),
                    TextFormField(
                      controller: _emailController,
                      decoration: InputDecoration(labelText: "Email"),
                      validator: (v) =>
                          !v!.contains("@") ? "Email invalide" : null,
                    ),
                    TextFormField(
                      controller: _passwordController,
                      decoration: InputDecoration(labelText: "Mot de passe"),
                      obscureText: true,
                      validator: (v) => v!.length < 6 ? "Trop court" : null,
                    ),
                    TextFormField(
                      controller: _phoneController,
                      decoration: InputDecoration(labelText: "Téléphone"),
                    ),
                    // Ajoute un sélecteur de rôle simple pour tester
                    DropdownButton<String>(
                      value: _selectedRole,
                      items: ['client', 'chauffeur', 'livreur'].map((role) {
                        return DropdownMenuItem(value: role, child: Text(role));
                      }).toList(),
                      onChanged: (val) => setState(() => _selectedRole = val!),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _submit,
                      child: Text("S'inscrire"),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
